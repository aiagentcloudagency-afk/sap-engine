
export async function small_talk(params: any) {
  return {
    intent: "small_talk",
    received: params,
    result: "Mock response for small_talk"
  };
}
