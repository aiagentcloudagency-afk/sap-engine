
export async function get_price(params: any) {
  return {
    intent: "get_price",
    received: params,
    result: "Mock response for get_price"
  };
}
