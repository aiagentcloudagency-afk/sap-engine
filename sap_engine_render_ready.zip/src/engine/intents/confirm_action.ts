
export async function confirm_action(params: any) {
  return {
    intent: "confirm_action",
    received: params,
    result: "Mock response for confirm_action"
  };
}
