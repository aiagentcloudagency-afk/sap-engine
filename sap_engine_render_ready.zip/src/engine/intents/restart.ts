
export async function restart(params: any) {
  return {
    intent: "restart",
    received: params,
    result: "Mock response for restart"
  };
}
