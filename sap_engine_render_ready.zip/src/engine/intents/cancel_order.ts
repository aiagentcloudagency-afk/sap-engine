
export async function cancel_order(params: any) {
  return {
    intent: "cancel_order",
    received: params,
    result: "Mock response for cancel_order"
  };
}
