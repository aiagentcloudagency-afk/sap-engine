
export async function create_delivery(params: any) {
  return {
    intent: "create_delivery",
    received: params,
    result: "Mock response for create_delivery"
  };
}
