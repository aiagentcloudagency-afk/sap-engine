
export async function get_stock(params: any) {
  return {
    intent: "get_stock",
    received: params,
    result: "Mock response for get_stock"
  };
}
