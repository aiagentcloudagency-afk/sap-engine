
export async function incoming_payment(params: any) {
  return {
    intent: "incoming_payment",
    received: params,
    result: "Mock response for incoming_payment"
  };
}
