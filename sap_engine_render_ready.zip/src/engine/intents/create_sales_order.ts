
export async function create_sales_order(params: any) {
  return {
    intent: "create_sales_order",
    received: params,
    result: "Mock response for create_sales_order"
  };
}
