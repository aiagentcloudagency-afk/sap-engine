
export async function unknown_intent(params: any) {
  return {
    intent: "unknown_intent",
    received: params,
    result: "Mock response for unknown_intent"
  };
}
