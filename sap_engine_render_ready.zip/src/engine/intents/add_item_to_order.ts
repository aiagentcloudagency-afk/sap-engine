
export async function add_item_to_order(params: any) {
  return {
    intent: "add_item_to_order",
    received: params,
    result: "Mock response for add_item_to_order"
  };
}
