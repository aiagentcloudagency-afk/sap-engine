
export async function update_order(params: any) {
  return {
    intent: "update_order",
    received: params,
    result: "Mock response for update_order"
  };
}
