
export async function fallback(params: any) {
  return {
    intent: "fallback",
    received: params,
    result: "Mock response for fallback"
  };
}
