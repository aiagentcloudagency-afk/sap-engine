
export async function bin_location_query(params: any) {
  return {
    intent: "bin_location_query",
    received: params,
    result: "Mock response for bin_location_query"
  };
}
