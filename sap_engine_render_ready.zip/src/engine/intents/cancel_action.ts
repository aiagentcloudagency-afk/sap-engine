
export async function cancel_action(params: any) {
  return {
    intent: "cancel_action",
    received: params,
    result: "Mock response for cancel_action"
  };
}
