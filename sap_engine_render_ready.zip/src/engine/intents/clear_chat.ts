
export async function clear_chat(params: any) {
  return {
    intent: "clear_chat",
    received: params,
    result: "Mock response for clear_chat"
  };
}
