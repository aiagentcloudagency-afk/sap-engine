
export async function help(params: any) {
  return {
    intent: "help",
    received: params,
    result: "Mock response for help"
  };
}
