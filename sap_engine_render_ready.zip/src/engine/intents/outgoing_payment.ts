
export async function outgoing_payment(params: any) {
  return {
    intent: "outgoing_payment",
    received: params,
    result: "Mock response for outgoing_payment"
  };
}
