
export async function summarize(params: any) {
  return {
    intent: "summarize",
    received: params,
    result: "Mock response for summarize"
  };
}
