
import { routeIntent } from "./router";

export async function handleRequest(body: any) {
  const intent = body.intent;
  const params = body.parameters || {};
  return await routeIntent(intent, params);
}
