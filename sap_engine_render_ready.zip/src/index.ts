
import { Hono } from "hono";
import { handleRequest } from "./engine/engine";

const app = new Hono();

app.post("/engine", async (c) => {
  const body = await c.req.json();
  const result = await handleRequest(body);
  return c.json(result);
});

export default app;
